﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlottaNavake
{

     internal class Nave
    {
        char nome;
        char stazza;
        char velocita;
        StatoNave statoNave;

        public Nave(char nome, char stazza, char velocita, StatoNave statoNave)
        {
            Nome = nome;
            Stazza = stazza;
            Velocita = velocita;
            StatoNave = statoNave;
        }

        public char Nome { get => nome; set => nome = value; }
        public char Stazza { get => stazza; set => stazza = value; }
        public char Velocita { get => velocita; set => velocita = value; }
        internal StatoNave StatoNave { get => statoNave; set => statoNave = value; }
    }
}
