﻿
namespace FlottaNavake
{
    public enum StatoNave
    {
        Cantiere,
        Varata,
        Demolita
    }
}
