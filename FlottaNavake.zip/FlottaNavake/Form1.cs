﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace FlottaNavake
{
    public partial class Form1 : Form
    {
        List<Nave> Nave = new List<Nave>();
        public Form1()
        {
            InitializeComponent();
        }

        private void naveToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void inserisciToolStripMenuItem_Click(object sender, EventArgs e)
        {
            InserimentoNave fm = new InserimentoNave();
            fm.ShowDialog();
            Nave n = new Nave(Convert.ToChar(fm.textBox1.Text), Convert.ToChar(fm.textbox3.Text), Convert.ToChar(fm.textBox2.Text), fm.stato);
            Nave.Add(n);
            dataGridView1.Rows.Add(n);
        }
        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }
    }
}
